/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto1_edd;

import java.util.*;

/**
 * Clase que representa un grafo dirigido usando lista de adyacencia.
 * Cada nodo es un usuario (String), y las aristas representan relaciones de seguimiento.
 * @author KelvinH
 * @version corregido 7/11/26
 */
public class Graph {
    private Map<String, List<String>> adjacencyList;

    /**
     * Constructor del grafo.
     */
    public Graph() {
        this.adjacencyList = new HashMap<>();
    }

    /**
     * Agrega un usuario (nodo) al grafo si no existe.
     * @param user El nombre del usuario.
     */
    public void addUser(String user) {
        adjacencyList.putIfAbsent(user, new ArrayList<>());
    }

    /**
     * Agrega una relación (arista dirigida) de un usuario a otro.
     * @param from Usuario que sigue.
     * @param to Usuario seguido.
     */
    public void addRelation(String from, String to) {
        addUser(from);
        addUser(to);
        adjacencyList.get(from).add(to);
    }

    /**
     * Elimina un usuario y todas sus relaciones.
     * @param user El usuario a eliminar.
     */
    public void removeUser(String user) {
        if (adjacencyList.containsKey(user)) {
            adjacencyList.remove(user);
            // Eliminar referencias entrantes
            for (List<String> neighbors : adjacencyList.values()) {
                neighbors.remove(user);
            }
        }
    }

    /**
     * Obtiene la lista de adyacencia.
     * @return Mapa de adyacencia.
     */
    public Map<String, List<String>> getAdjacencyList() {
        return adjacencyList;
    }

    /**
     * Obtiene todos los usuarios (nodos).
     * @return Conjunto de usuarios.
     */
    public Set<String> getUsers() {
        return adjacencyList.keySet();
    }

    /**
     * Transpone el grafo (invierte las direcciones de las aristas).
     * @return Nuevo grafo transpuesto.
     */
    public Graph transpose() {
        Graph transposed = new Graph();
        for (String user : adjacencyList.keySet()) {
            transposed.addUser(user);
        }
        for (Map.Entry<String, List<String>> entry : adjacencyList.entrySet()) {
            String from = entry.getKey();
            for (String to : entry.getValue()) {
                transposed.addRelation(to, from);
            }
        }
        return transposed;
    }

    /**
     * Realiza DFS desde un nodo y registra el orden de finalización.
     * @param node Nodo actual.
     * @param visited Conjunto de visitados.
     * @param stack Pila para orden de finalización.
     */
    public void dfs(String node, Set<String> visited, Stack<String> stack) {
        visited.add(node);
        for (String neighbor : adjacencyList.getOrDefault(node, new ArrayList<>())) {
            if (!visited.contains(neighbor)) {
                dfs(neighbor, visited, stack);
            }
        }
        stack.push(node);
    }
}
