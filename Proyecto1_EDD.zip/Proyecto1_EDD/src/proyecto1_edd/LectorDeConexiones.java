/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto1_edd;


import org.graphstream.graph.Graph;
import org.graphstream.graph.implementations.SingleGraph;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author USUARIO
 */

public class LectorDeConexiones {
    public Graph construirGrafoDesdeArchivo(String rutaArchivo) {
        System.setProperty("org.graphstream.ui", "swing"); 
        
        Graph graph = new SingleGraph("UsuariosYRelaciones");
        String css = "node {"
                + " fill-color: blue; "
                + " size: 60px; "
                + " text-mode: normal; "
                + " text-size: 14; "
                + " text-alignment: center; "
                + " text-color: white; "
                + " padding: 5px;} "
                + "edge {"
                + " fill-color: gray; "
                + "arrow-shape: arrow; "
                + "arrow-size: 50px, 50px; "
                + "shape: cubic-curve; "
                + "}";
        graph.setAttribute("ui.stylesheet", css);

        try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            boolean esUsuarios = true;

            while ((linea = br.readLine()) != null) {
                linea = linea.trim();
                
                if (linea.isEmpty() || linea.startsWith("#")) {
                    continue; 
                }

                if (linea.equalsIgnoreCase("usuarios")) {
                    esUsuarios = true;
                    continue;
                } else if (linea.equalsIgnoreCase("relaciones")) {
                    esUsuarios = false;
                    continue;
                }

                if (linea.startsWith("@")) {
                    String nombre = linea.substring(1).trim();

                    if (esUsuarios) {
                        // Crear nodos
                        if (graph.getNode(nombre) == null) {
                            graph.addNode(nombre).setAttribute("ui.label", nombre);
                        }
                    } else {
                        // Crear aristas (relaciones)
                        String[] partes = nombre.split(",");
                        if (partes.length == 2) {
                            String nodoA = partes[0].trim();
                            String nodoB = partes[1].trim();                          
                            
                            if (graph.getNode(nodoA) == null) graph.addNode(nodoA).setAttribute("ui.label", nodoA);
                            if (graph.getNode(nodoB) == null) graph.addNode(nodoB).setAttribute("ui.label", nodoB);                          
                            String edgeId = nodoA + "->" + nodoB;
                            if (graph.getEdge(edgeId) == null) {
                                graph.addEdge(edgeId, nodoA, nodoB, true); 
                            }
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return graph;
    }
}