/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto1_edd;

import java.util.*;

/**
 * Clase que implementa el algoritmo de Kosaraju para encontrar componentes fuertemente conectados.
 * @author KelvinH
 * @version corregido 7/11/26
 */
public class Kosaraju {
    private Graph graph;

    /**
     * Constructor.
     * @param graph El grafo a analizar.
     */
    public Kosaraju(Graph graph) {
        this.graph = graph;
    }

    /**
     * Encuentra los componentes fuertemente conectados.
     * @return Lista de listas, cada una representando un SCC.
     */
    public List<List<String>> findSCCs() {
        List<List<String>> sccs = new ArrayList<>();
        Set<String> visited = new HashSet<>();
        Stack<String> stack = new Stack<>();

        // Paso 1: DFS en el grafo original para obtener orden de finalización
        for (String node : graph.getUsers()) {
            if (!visited.contains(node)) {
                graph.dfs(node, visited, stack);
            }
        }

        // Paso 2: Transponer el grafo
        Graph transposed = graph.transpose();
        visited.clear();

        // Paso 3: DFS en el grafo transpuesto en orden de finalización
        while (!stack.isEmpty()) {
            String node = stack.pop();
            if (!visited.contains(node)) {
                List<String> component = new ArrayList<>();
                dfsTransposed(transposed, node, visited, component);
                sccs.add(component);
            }
        }

        return sccs;
    }

    /**
     * DFS en el grafo transpuesto para formar un componente.
     * @param transposed Grafo transpuesto.
     * @param node Nodo actual.
     * @param visited Conjunto de visitados.
     * @param component Lista del componente actual.
     */
    private void dfsTransposed(Graph transposed, String node, Set<String> visited, List<String> component) {
        visited.add(node);
        component.add(node);
        for (String neighbor : transposed.getAdjacencyList().getOrDefault(node, new ArrayList<>())) {
            if (!visited.contains(neighbor)) {
                dfsTransposed(transposed, neighbor, visited, component);
            }
        }
    }
}
