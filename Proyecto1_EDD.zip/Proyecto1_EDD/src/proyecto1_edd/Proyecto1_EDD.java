/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyecto1_edd;

import javax.swing.SwingUtilities;
/**
 * Clase principal que inicia la aplicación.
 * Carga archivo y muestra resultados en consola.
 * @author KelvinH
 * @version corregido 7/11/26
 */
public class Proyecto1_EDD {

    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Interfaz frame = new Interfaz();
            frame.setVisible(true);
        });
    }
    
}
